
package com.mycompany.proyecto1;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Tarjetausuario extends javax.swing.JFrame {
private ArrayList<String> tarjetasRegistradas = new ArrayList<>();
  
    public Tarjetausuario() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        txt_numero = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_fechaVencimiento = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btn_registrar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nombre Titular");

        jLabel2.setText("Numero Tarjeta");

        jLabel3.setText("Fecha vencimiento");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        btn_registrar.setText("Registrar");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });

        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_fechaVencimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE)
                            .addComponent(txt_numero)
                            .addComponent(txt_nombre))))
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_registrar)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton1)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_fechaVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_registrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        // TODO add your handling code here:
        String nombre = txt_nombre.getText();
    String numero = txt_numero.getText();
    String fechaVencimiento = txt_fechaVencimiento.getText();
    
    // Validar que el número de tarjeta solo tenga números
    if (!numero.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "El número de tarjeta debe ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // Validar que la tarjeta no esté registrada
    for (String tarjetaRegistrada : tarjetasRegistradas) {
        String numeroRegistrado = tarjetaRegistrada.substring(tarjetaRegistrada.indexOf("Numero: ") + 8, tarjetaRegistrada.indexOf(", Fecha"));
        if (numeroRegistrado.equals(numero)) {
            JOptionPane.showMessageDialog(this, "La tarjeta ya está registrada", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    
    String tarjeta = "Nombre: " + nombre + ", Numero: " + numero + ", Fecha de vencimiento: " + fechaVencimiento;
    tarjetasRegistradas.add(tarjeta);
    actualizarTextArea();
    
    }//GEN-LAST:event_btn_registrarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

   private void actualizarTextArea() {
        StringBuilder sb = new StringBuilder();
    for (String tarjeta : tarjetasRegistradas) {
        // Ofuscar los últimos 4 dígitos del número de tarjeta
        String numero = tarjeta.substring(tarjeta.indexOf("Numero: ") + 8, tarjeta.indexOf(", Fecha"));
        String ofuscado = "XXXX" + numero.substring(numero.length() - 4);
        String tarjetaOfuscada = tarjeta.replace(numero, ofuscado);
        // Mostrar solo los últimos 4 caracteres del número de tarjeta
        String tarjetaCorta = tarjetaOfuscada.substring(0, tarjetaOfuscada.indexOf("Numero: ") + 8) + "XXXX" + numero.substring(numero.length() - 4);
        // Agregar la fecha de vencimiento al final de la cadena tarjetaCorta
        tarjetaCorta += tarjeta.substring(tarjeta.indexOf(", Fecha de vencimiento:"));
        sb.append(tarjetaCorta).append("\n");
    }
    jTextArea1.setText(sb.toString());
    }
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tarjetausuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_registrar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField txt_fechaVencimiento;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_numero;
    // End of variables declaration//GEN-END:variables
}
