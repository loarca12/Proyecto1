
package com.mycompany.proyecto1;


public class Kiosko {
    private String codigo;
    private String nombre;
    private char codigoRegion;
    
    public Kiosko(String codigo, String nombre, char codigoRegion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.codigoRegion = codigoRegion;
    }
    
    // Métodos getters y setters
    public String getCodigo() {
        return codigo;
    }
    
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public char getCodigoRegion() {
        return codigoRegion;
    }
    
    public void setCodigoRegion(char codigoRegion) {
        this.codigoRegion = codigoRegion;
    }
}
