/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto1;


public class Region {
private String codigo;
    private String nombre;
    private double precioEstandar;
    private double precioEspecial;
    
    public Region(String codigo, String nombre, double precioEstandar, double precioEspecial) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precioEstandar = precioEstandar;
        this.precioEspecial = precioEspecial;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecioEstandar(double precioEstandar) {
        this.precioEstandar = precioEstandar;
    }

    public void setPrecioEspecial(double precioEspecial) {
        this.precioEspecial = precioEspecial;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public double getPrecioEstandar() {
        return precioEstandar;
    }
    
    public double getPrecioEspecial() {
        return precioEspecial;
    }
}
