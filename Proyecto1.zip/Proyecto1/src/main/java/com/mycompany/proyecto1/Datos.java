/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Singleton.java to edit this template
 */
package com.mycompany.proyecto1;

import java.util.ArrayList;

/**
 *
 * @author gcifuentes
 */
public class Datos {
    private static final Datos instancia = new Datos();
    private ArrayList<Region> listaRegiones = new ArrayList<>();
    private Datos() {
    }
    
    public static Datos getInstance() {
        return instancia;
    }
    public ArrayList<Region> getListaRegiones() {
        return listaRegiones;
    }
    public void setListaRegiones(ArrayList<Region> listaRegiones) {
    this.listaRegiones = listaRegiones;
}
    
    private static class DatosHolder {

        private static final Datos INSTANCE = new Datos();
    }
}
