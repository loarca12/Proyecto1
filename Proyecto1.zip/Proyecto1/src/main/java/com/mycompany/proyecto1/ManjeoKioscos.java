/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyecto1;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;




public class ManjeoKioscos extends javax.swing.JFrame {
    
  // Declarar un ArrayList de kioscos
    private ArrayList<Kiosko> listaKioskos = new ArrayList<>();
    
    // Declarar un modelo de lista para mostrar los kioscos
    private DefaultListModel<String> modeloLista = new DefaultListModel<>();
    
        

    /**
     * Creates new form ManejoKioscos
     */
    public ManjeoKioscos() {
        initComponents();
        // Configurar la ventana principal
         setLocationRelativeTo(null);
        
        // Asignar el modelo de lista al componente visual de la lista
        list_verKioskos.setModel(modeloLista);
        
        cb_codigoregion.addItem("M");
        cb_codigoregion.addItem("NT");
        cb_codigoregion.addItem("NO");
        cb_codigoregion.addItem("SO");
        cb_codigoregion.addItem("SOC");
        cb_codigoregion.addItem("NOC");
        
    }
 private void agregarKiosco() {
        // Obtener los valores ingresados en los campos de texto
         String codigo = txt_codigo.getText();
        String nombre = txt_nombre.getText();
        char codigoRegion = cb_codigoregion.getSelectedItem().toString().charAt(0);
        
        // Verificar que los campos no estén vacíos
        if (codigo.isEmpty() || nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son requeridos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar que el campo de código solo contenga números
        if (!codigo.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "El código debe ser un número", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        //validar si ya existe uno con el mismo codigo
        for (Kiosko kiosko : listaKioskos) {
        if (kiosko.getCodigo().equals(codigo)) {
            JOptionPane.showMessageDialog(this, "Ya existe un kiosco con el mismo código", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
        // Crear un nuevo objeto Kiosko
        Kiosko kiosko = new Kiosko(codigo, nombre, codigoRegion);
        
        // Agregar el objeto a la lista de kioscos
        listaKioskos.add(kiosko);
        
        // Limpiar los campos de texto y el combobox
        txt_codigo.setText("");
        txt_nombre.setText("");
        cb_codigoregion.setSelectedIndex(0);
        
        // Actualizar el modelo de lista
        modeloLista.addElement(kiosko.getCodigo() + " - " + kiosko.getNombre() + " - " + kiosko.getCodigoRegion());
        
        // Mostrar un mensaje de éxito
        JOptionPane.showMessageDialog(this, "Kiosko agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Método para mostrar los kioscos en la lista
    private void mostrarKioscos() {
        // Limpiar el modelo de lista
        modeloLista.clear();
        
        // Recorrer la lista de kioscos y agregarlos al modelo de lista
        for (Kiosko kiosko : listaKioskos) {
            modeloLista.addElement(kiosko.getCodigo() + " - " + kiosko.getNombre() + " - " + kiosko.getCodigoRegion());
        }
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_codigo = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        btn_agregar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        list_verKioskos = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cb_codigoregion = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btn_agregar.setText("AGREGAR");
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(list_verKioskos);

        jLabel1.setText("NOMBRE KIOSKO");

        jLabel2.setText("CODIGO KIOSKO");

        jLabel3.setText("CODIGO REGION");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btn_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_codigo)
                            .addComponent(txt_nombre, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                            .addComponent(jLabel1))
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel3)
                    .addComponent(cb_codigoregion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addGap(3, 3, 3)
                        .addComponent(txt_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(cb_codigoregion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                        .addComponent(btn_agregar)))
                .addGap(30, 30, 30))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        agregarKiosco();
    }//GEN-LAST:event_btn_agregarActionPerformed

    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManjeoKioscos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManjeoKioscos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManjeoKioscos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManjeoKioscos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManjeoKioscos().setVisible(true);
            }
        });
    }//

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregar;
    private javax.swing.JComboBox<String> cb_codigoregion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> list_verKioskos;
    private javax.swing.JTextField txt_codigo;
    private javax.swing.JTextField txt_nombre;
    // End of variables declaration//GEN-END:variables
}
