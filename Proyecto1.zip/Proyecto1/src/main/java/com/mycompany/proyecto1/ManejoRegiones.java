/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyecto1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ManejoRegiones extends javax.swing.JFrame {

   private ArrayList<Region> listaRegiones = new ArrayList<>();
    private DefaultTableModel modeloTabla = new DefaultTableModel(
        new Object[][] {},
        new String[] {"Código", "Nombre", "Precio Estándar", "Precio Especial"}
             );
    public ManejoRegiones() {
        initComponents();
        listaRegiones.add(new Region("M", "Metropolitana", 35.0, 25.0));
        listaRegiones.add(new Region("NT", "Norte", 68.5, 45.55));
        listaRegiones.add(new Region("NO", "Nororiente", 58.68, 35.48));
        listaRegiones.add(new Region("SO", "Suroriente", 38.68, 32.48));
        listaRegiones.add(new Region("SOC", "Suroccidente", 34.0, 29.0));
        listaRegiones.add(new Region("NOC", "Noroccidente", 44.5, 40.0));
        
        for (Region region : listaRegiones) {
            modeloTabla.addRow(new Object[] {region.getCodigo(), region.getNombre(),
                region.getPrecioEstandar(), region.getPrecioEspecial()});
        }
        tblRegiones.setModel(modeloTabla);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblRegiones = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        GuardarCambios = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblRegiones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(tblRegiones);

        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        GuardarCambios.setText("Guardar");
        GuardarCambios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarCambiosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 513, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(GuardarCambios))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(GuardarCambios, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        Principal1 pantallaPrincipal = new Principal1();
    pantallaPrincipal.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void GuardarCambiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarCambiosActionPerformed
        // TODO add your handling code here:
        listaRegiones = Datos.getInstance().getListaRegiones();
   for (int i = 0; i < modeloTabla.getRowCount(); i++) {
    String codigo = (String) modeloTabla.getValueAt(i, 0);
    String nombre = (String) modeloTabla.getValueAt(i, 1);
    double precioEstandar = (double) modeloTabla.getValueAt(i, 2);
    double precioEspecial = (double) modeloTabla.getValueAt(i, 3);

    // Buscar la región en la lista y actualizar sus datos
    for (Region region : listaRegiones) {
        if (region.getCodigo().equals(codigo)) {
            region.setNombre(nombre);
            region.setPrecioEstandar(precioEstandar);
            region.setPrecioEspecial(precioEspecial);
            break;
        }
    }
}

// Cargar los datos actualizados en la tabla
modeloTabla.setRowCount(0);
for (Region region : listaRegiones) {
    modeloTabla.addRow(new Object[] {region.getCodigo(), region.getNombre(),
            region.getPrecioEstandar(), region.getPrecioEspecial()});
}

    // Mostrar mensaje de éxito
    JOptionPane.showMessageDialog(this, "Cambios guardados correctamente");
Datos.getInstance().setListaRegiones(listaRegiones);
    }//GEN-LAST:event_GuardarCambiosActionPerformed
/*private void cargarRegiones() {
        listaRegiones.add(new Region("M", "Metropolitana", 35.0, 25.0));
        listaRegiones.add(new Region("NT", "Norte", 68.5, 45.55));
        listaRegiones.add(new Region("NO", "Nororiente", 58.68, 35.48));
        listaRegiones.add(new Region("SO", "Suroriente", 38.68, 32.48));
        listaRegiones.add(new Region("SOC", "Suroccidente", 34.0, 29.0));
        listaRegiones.add(new Region("NOC", "Noroccidente", 44.5, 40.0));
        
        for (Region region : listaRegiones) {
            modeloTabla.addRow(new Object[] {region.getCodigo(), region.getNombre(),
                region.getPrecioEstandar(), region.getPrecioEspecial()});
        }
    }*/
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManejoRegiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManejoRegiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManejoRegiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManejoRegiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManejoRegiones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton GuardarCambios;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblRegiones;
    // End of variables declaration//GEN-END:variables
}
