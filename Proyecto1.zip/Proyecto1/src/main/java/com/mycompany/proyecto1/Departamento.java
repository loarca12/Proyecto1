
package com.mycompany.proyecto1;


public class Departamento {
  private String codigoRegion;
    private String nombre;

    public Departamento(String codigoRegion, String nombre) {
        this.codigoRegion = codigoRegion;
        this.nombre = nombre;
    }

    public String getCodigoRegion() {
        return codigoRegion;
    }

    public void setCodigoRegion(String codigoRegion) {
        this.codigoRegion = codigoRegion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }  
}
